export interface Message {
    title: string;
    body: string;
}
